<?php
// Database credentials
$servername = "localhost";  // Your database server
$username = "root";         // Your database username
$password = "";             // Your database password
$dbname = "msd_godspeed";   // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form data is received via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and fetch form data
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $message = $conn->real_escape_string($_POST['message']);
    $department = $conn->real_escape_string($_POST['department']);
    
    // Insert data into the database
    $sql = "INSERT INTO messages (name, email, message, department) VALUES ('$name', '$email', '$message', '$department')";

    if ($conn->query($sql) === TRUE) {
        // Success response
        echo json_encode(["status" => "success", "message" => "Message saved to database!"]);
    } else {
        // Error response
        echo json_encode(["status" => "error", "message" => "Error: " . $conn->error]);
    }

    // Close connection
    $conn->close();
} else {
    // Invalid request method
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
