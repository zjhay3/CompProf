<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image View</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #002d02;
            margin: 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
            color: white;
            text-align: center;
        }
        img {
            max-width: 90%;
            max-height: 80vh;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.5);
        }
        .image-text {
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
            max-width: 80%;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background: white;
            padding: 10px 15px;
            text-decoration: none;
            color: black;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <a href="#about" class="back-button">&larr; Back</a>
    <img id="fullImage" src="" alt="Full View">
    <p id="imageText" class="image-text"></p>

    <script>
        // Get image name and text from URL
        const urlParams = new URLSearchParams(window.location.search);
        const imageName = urlParams.get('image');
        let imageText = urlParams.get('text'); // Get the text from URL

        // Set image source
        if (imageName) {
            document.getElementById('fullImage').src = "images/" + imageName;
        } else {
            document.getElementById('fullImage').alt = "No image found.";
        }

        // Ensure proper decoding of new lines and special characters
        if (imageText) {
            imageText = decodeURIComponent(imageText).replace(/\n/g, "<br>").replace(/%0A/g, "<br>"); 
            document.getElementById('imageText').innerHTML = imageText; // Use innerHTML to support <br>
        } else {
            document.getElementById('imageText').innerText = "No description available.";
        }

        // Back button behavior
        document.querySelector(".back-button").addEventListener("click", function (event) {
            event.preventDefault();
            history.back(); // Navigate back naturally
        });

        // Ensure homepage reloads properly after going back
        window.addEventListener("pageshow", function(event) {
            if (event.persisted) {
                window.location.reload(); // Reload only if returning from cache
            }
        });

    </script>
</body>
</html>
